//Author: Cppbuzz.com
//Note: Users can download & modify this project as per their requirement

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
